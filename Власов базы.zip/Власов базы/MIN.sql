SELECT MIN(Price) FROM Productse;
