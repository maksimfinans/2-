SELECT BOOL_OR(IsDiscounted) FROM Productse;
