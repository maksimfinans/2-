SELECT FirstName, CreatedAt, ProductCount, Price
FROM Thh FULL JOIN Jim
ON Jim.ThhId=Thh.Id;
