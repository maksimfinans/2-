update posts
set tags[2]='system'
where id=1;
