SELECT FirstName, LastName
FROM Drim
EXCEPT SELECT FirstName,LastName
FROM Raap;
