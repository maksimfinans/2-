SELECT AVG(Price) FROM Productse
WHERE Company='Apple';