s = input()
count_lower = 0
count_upper = 0
i = 0
while i < len(s):
    if s[i].islower(): count_lower += 1
    if s[i].isupper(): count_upper += 1
    i += 1
print(count_lower, count_upper)