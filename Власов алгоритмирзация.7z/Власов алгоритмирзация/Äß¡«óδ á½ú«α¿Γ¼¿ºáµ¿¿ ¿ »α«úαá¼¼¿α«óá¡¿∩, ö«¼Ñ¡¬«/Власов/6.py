def add_spaces_to_words():
    M = int(input("Введите количество строк: "))
    words = []
    for _ in range(M):
        word = input("Введите слово: ")
        words.append(word)
    spaced_words = [' '.join(word) for word in words]
    print("Слова с пробелами между буквами:")
    for spaced_word in spaced_words:
        print(spaced_word)
add_spaces_to_words()
