def normalize_string(input_string):
    trimmed_string = input_string.strip()
    normalized_string = ' '.join(trimmed_string.split())
    return normalized_string
input_string = input()
normalized = normalize_string(input_string)
print(normalized)
