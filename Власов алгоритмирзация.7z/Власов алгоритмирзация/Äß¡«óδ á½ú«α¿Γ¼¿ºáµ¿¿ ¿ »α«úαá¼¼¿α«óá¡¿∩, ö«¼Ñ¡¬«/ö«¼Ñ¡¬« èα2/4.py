def max_max(a, b, c):
    return max(a, b, c)
result = max_max(10, 20, 15)
print(result)