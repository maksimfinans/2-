def maximum(a, b, c,):
    list = [a, b, c]
    list.sort()
    return list[-1]
print(maximum(5, 6, 7))