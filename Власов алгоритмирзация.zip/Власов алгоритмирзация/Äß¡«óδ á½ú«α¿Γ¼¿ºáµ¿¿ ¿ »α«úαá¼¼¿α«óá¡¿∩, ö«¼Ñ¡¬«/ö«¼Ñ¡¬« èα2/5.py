def sum_l(numbers):
    total = 0
    for num in numbers:
        total += num
    return total
list = [1, 2, 3, 4, 5]
result = sum_l(list)
print(result)