def mlp(numbers):
    result = 1
    for number in numbers:
        result *= number
    return result
numbers = [2, 3, 4]
print(mlp(numbers))